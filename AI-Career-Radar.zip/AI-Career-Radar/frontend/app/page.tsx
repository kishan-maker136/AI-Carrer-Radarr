'use client'

import React, { useState } from 'react'
import { FiRadio, FiDatabase, FiSearch, FiTarget, FiTrendingUp, FiCpu, FiActivity } from 'react-icons/fi'
import FetchJobs from './sections/FetchJobs'
import SearchJobs from './sections/SearchJobs'
import JobRecommendations from './sections/JobRecommendations'

type Tab = 'fetch' | 'search' | 'recommend'

const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'fetch', label: 'Fetch Jobs', icon: <FiDatabase className="w-4 h-4" /> },
  { id: 'search', label: 'Search Jobs', icon: <FiSearch className="w-4 h-4" /> },
  { id: 'recommend', label: 'Recommendations', icon: <FiTarget className="w-4 h-4" /> },
]

function getTabStyles(tab: Tab, active: boolean) {
  if (!active) return 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
  const map: Record<Tab, string> = {
    fetch: 'text-blue-400 bg-blue-500/15 border-blue-500/30 shadow-blue-500/10 shadow-lg',
    search: 'text-purple-400 bg-purple-500/15 border-purple-500/30 shadow-purple-500/10 shadow-lg',
    recommend: 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30 shadow-emerald-500/10 shadow-lg',
  }
  return map[tab]
}

export default function Page() {
  const [activeTab, setActiveTab] = useState<Tab>('fetch')

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      {/* Background Gradient Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[15%] w-[500px] h-[500px] bg-purple-600/8 rounded-full blur-[150px]" />
        <div className="absolute bottom-[-10%] right-[15%] w-[500px] h-[500px] bg-blue-600/8 rounded-full blur-[150px]" />
        <div className="absolute top-[40%] left-[50%] -translate-x-1/2 w-[600px] h-[600px] bg-emerald-600/5 rounded-full blur-[180px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <header className="mb-8 animate-fadeInUp">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-500/20
              shadow-lg shadow-purple-500/10">
              <FiRadio className="w-7 h-7 text-purple-400" />
            </div>
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
                AI Career Radar
              </h1>
              <p className="text-gray-400 text-sm mt-0.5">
                Your intelligent career assistant -- powered by AI
              </p>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="flex items-center gap-6 mt-6 p-4 rounded-2xl bg-gray-900/50 border border-gray-800 backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <FiTrendingUp className="w-4 h-4 text-emerald-400" />
              <span className="text-xs text-gray-400">AI-Powered</span>
            </div>
            <span className="text-gray-700">|</span>
            <div className="flex items-center gap-2">
              <FiDatabase className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-gray-400">Real-time Data</span>
            </div>
            <span className="text-gray-700">|</span>
            <div className="flex items-center gap-2">
              <FiTarget className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-gray-400">Smart Matching</span>
            </div>
            <span className="text-gray-700">|</span>
            <div className="flex items-center gap-2">
              <FiActivity className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-gray-400">Live Analysis</span>
            </div>
          </div>
        </header>

        {/* AI Insight Box */}
        <div className="mb-6 p-4 rounded-2xl bg-blue-900/20 border border-blue-500/30 backdrop-blur-sm
          animate-fadeInUp transition-all duration-300 hover:border-blue-500/50"
          style={{ animationDelay: '80ms' }}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-blue-500/20 mt-0.5">
              <FiCpu className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <p className="text-sm font-semibold text-blue-300 mb-1">AI Insight</p>
              <p className="text-sm text-gray-300 leading-relaxed">
                Python + AI roles are trending high in the market. Full-stack and cloud-native skills
                continue to see strong demand. Focused recommendations are applied based on current
                market signals and hiring patterns.
              </p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex gap-2 mb-8 p-1.5 rounded-2xl bg-gray-900/50 border border-gray-800 backdrop-blur-sm animate-fadeInUp"
          style={{ animationDelay: '160ms' }}
        >
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-medium
                border border-transparent transition-all duration-300 ${getTabStyles(tab.id, activeTab === tab.id)}`}
            >
              {tab.icon}
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </nav>

        {/* Content Area */}
        <main
          className="rounded-2xl bg-gray-900/50 border border-gray-800 backdrop-blur-xl p-6 sm:p-8 animate-fadeInUp
            shadow-xl shadow-black/20"
          style={{ animationDelay: '240ms' }}
        >
          {activeTab === 'fetch' && <FetchJobs />}
          {activeTab === 'search' && <SearchJobs />}
          {activeTab === 'recommend' && <JobRecommendations />}
        </main>

        {/* Footer */}
        <footer className="text-center mt-10 text-xs text-gray-600">
          Built with Next.js -- AI Career Radar Dashboard
        </footer>
      </div>
    </div>
  )
}
