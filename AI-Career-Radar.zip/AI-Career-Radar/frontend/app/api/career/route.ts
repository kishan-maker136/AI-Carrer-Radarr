import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.CAREER_API_URL || 'http://localhost:8000'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { action, query, skills } = body

    let url = ''
    let fetchOptions: RequestInit = {
      headers: { 'Content-Type': 'application/json' },
    }

    switch (action) {
      case 'fetch':
        url = `${BACKEND_URL}/fetch`
        fetchOptions.method = 'GET'
        break
      case 'search':
        url = `${BACKEND_URL}/search`
        fetchOptions.method = 'POST'
        fetchOptions.body = JSON.stringify({ query: query || '' })
        break
      case 'recommend':
        url = `${BACKEND_URL}/recommend`
        fetchOptions.method = 'POST'
        fetchOptions.body = JSON.stringify({ skills: skills || [] })
        break
      default:
        return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 })
    }

    const response = await fetch(url, fetchOptions)

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error')
      return NextResponse.json(
        { success: false, error: `Backend returned ${response.status}: ${errorText}` },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json({ success: true, data })
  } catch (error: any) {
    console.error('Career API error:', error)
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to connect to backend' },
      { status: 500 }
    )
  }
}
