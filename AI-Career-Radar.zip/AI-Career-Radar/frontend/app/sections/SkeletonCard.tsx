'use client'

import React from 'react'

export default function SkeletonCard() {
  return (
    <div className="p-5 bg-gray-900/80 border border-gray-800 rounded-2xl animate-pulse">
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <div className="h-5 bg-gray-700/60 w-3/5 mb-2.5 rounded-lg" />
          <div className="h-3.5 bg-gray-700/40 w-2/5 rounded-lg" />
        </div>
        <div className="h-8 w-16 bg-gray-700/40 rounded-lg" />
      </div>
      <div className="flex gap-2 mb-3">
        <div className="h-6 bg-gray-700/30 w-20 rounded-full" />
        <div className="h-6 bg-gray-700/30 w-24 rounded-full" />
      </div>
      <div className="mb-3">
        <div className="h-3 bg-gray-700/20 w-20 mb-2 rounded" />
        <div className="flex gap-1.5">
          <div className="h-5 bg-gray-700/30 w-14 rounded-md" />
          <div className="h-5 bg-gray-700/30 w-16 rounded-md" />
          <div className="h-5 bg-gray-700/30 w-12 rounded-md" />
        </div>
      </div>
      <div className="h-1.5 bg-gray-700/30 w-full rounded-full mt-4" />
      <div className="flex justify-between items-center mt-4 pt-3 border-t border-gray-800/50">
        <div className="h-3 bg-gray-700/20 w-24 rounded" />
        <div className="h-8 bg-gray-700/40 w-24 rounded-lg" />
      </div>
    </div>
  )
}
