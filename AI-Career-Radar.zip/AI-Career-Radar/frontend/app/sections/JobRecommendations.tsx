'use client'

import React, { useState } from 'react'
import { FiTarget, FiLoader, FiAlertCircle, FiPlus, FiX, FiZap, FiCpu, FiSearch, FiArrowDown } from 'react-icons/fi'
import JobCard from './JobCard'
import SkeletonCard from './SkeletonCard'
import { Job } from '@/lib/types/career'

type SortOption = 'match' | 'latest'

function parseRecommendations(data: any): { jobs: Job[]; missingSkills: string[] } {
  if (!data) return { jobs: [], missingSkills: [] }

  let jobs: Job[] = []
  let missingSkills: string[] = []

  if (Array.isArray(data)) {
    jobs = data
  } else {
    // Backend /recommend returns { data: [...] }
    const candidates = data.data || data.jobs || data.recommendations || data.matched_jobs || data.results
    if (Array.isArray(candidates)) {
      jobs = candidates
    } else if (candidates && typeof candidates === 'object') {
      for (const key of Object.keys(candidates)) {
        if (Array.isArray(candidates[key]) && candidates[key].length > 0) {
          jobs = candidates[key]
          break
        }
      }
    }
    if (jobs.length === 0 && data.data) {
      const nested = data.data
      const nestedJobs = nested.jobs || nested.recommendations || nested.matched_jobs || nested.results
      if (Array.isArray(nestedJobs)) jobs = nestedJobs
    }
  }

  if (Array.isArray(data.missing_skills)) {
    missingSkills = data.missing_skills
  } else if (data.data && Array.isArray(data.data.missing_skills)) {
    missingSkills = data.data.missing_skills
  }

  jobs = jobs.map((job) => ({
    ...job,
    missing_skills: Array.isArray(job.missing_skills) ? job.missing_skills : [],
  }))

  return { jobs, missingSkills }
}

function sortJobs(jobs: Job[], sort: SortOption): Job[] {
  const sorted = [...jobs]
  if (sort === 'match') {
    sorted.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0))
  } else {
    sorted.sort((a, b) => {
      const dateA = a.posted_date ? new Date(a.posted_date).getTime() : 0
      const dateB = b.posted_date ? new Date(b.posted_date).getTime() : 0
      return dateB - dateA
    })
  }
  return sorted
}

const SUGGESTED_SKILLS = [
  'Python', 'JavaScript', 'React', 'Node.js', 'TypeScript', 'SQL',
  'AWS', 'Docker', 'Machine Learning', 'Java', 'Go', 'Kubernetes',
]

export default function JobRecommendations() {
  const [skills, setSkills] = useState<string[]>([])
  const [inputValue, setInputValue] = useState('')
  const [jobs, setJobs] = useState<Job[]>([])
  const [globalMissing, setGlobalMissing] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [searched, setSearched] = useState(false)
  const [sortBy, setSortBy] = useState<SortOption>('match')

  const addSkill = (skill: string) => {
    const trimmed = skill.trim()
    if (trimmed && !skills.includes(trimmed)) {
      setSkills([...skills, trimmed])
    }
    setInputValue('')
  }

  const removeSkill = (skill: string) => {
    setSkills(skills.filter((s) => s !== skill))
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault()
      addSkill(inputValue)
    }
  }

  const getRecommendations = async () => {
    if (skills.length === 0) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/career', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'recommend', skills }),
      })
      const result = await res.json()
      if (result.success) {
        const parsed = parseRecommendations(result.data)
        setJobs(parsed.jobs)
        setGlobalMissing(parsed.missingSkills)
        setSearched(true)
      } else {
        setError(result.error || 'Failed to get recommendations')
      }
    } catch (err: any) {
      setError(err.message || 'Network error')
    } finally {
      setLoading(false)
    }
  }

  const displayJobs = sortJobs(jobs, sortBy)

  return (
    <section>
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30">
          <FiTarget className="w-5 h-5 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white">Job Recommendations</h2>
          <p className="text-sm text-gray-400">Get matched jobs based on your skill set</p>
        </div>
      </div>

      {/* Skill Input */}
      <div className="mb-4">
        <div className="flex gap-3 mb-3">
          <div className="relative flex-1">
            <FiPlus className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a skill and press Enter..."
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-gray-900/80 border border-gray-800 text-white
                placeholder:text-gray-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1
                focus:ring-emerald-500/25 transition-all text-sm"
            />
          </div>
          <button
            onClick={getRecommendations}
            disabled={loading || skills.length === 0}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium
              bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90
              text-white transition-all duration-200
              disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-emerald-500/25"
          >
            {loading ? <FiLoader className="w-4 h-4 animate-spin" /> : <FiZap className="w-4 h-4" />}
            {loading ? 'Matching...' : 'Get Matches'}
          </button>
        </div>

        {/* Selected Skills */}
        {skills.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {skills.map((skill) => (
              <span
                key={skill}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium
                  bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
              >
                {skill}
                <button onClick={() => removeSkill(skill)} className="hover:text-white transition-colors">
                  <FiX className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        )}

        {/* Suggested Skills */}
        {skills.length < 5 && (
          <div className="flex flex-wrap gap-1.5">
            <span className="text-xs text-gray-500 mr-1 self-center">Quick add:</span>
            {SUGGESTED_SKILLS.filter((s) => !skills.includes(s))
              .slice(0, 8)
              .map((skill) => (
                <button
                  key={skill}
                  onClick={() => addSkill(skill)}
                  className="px-2.5 py-1 rounded-md text-xs bg-gray-800/60 text-gray-400
                    hover:bg-gray-700/80 hover:text-gray-200 border border-gray-700/40 transition-all"
                >
                  + {skill}
                </button>
              ))}
          </div>
        )}
      </div>

      {/* AI Thinking State */}
      {loading && (
        <>
          <div className="flex items-center gap-2 p-3 mb-4 rounded-xl bg-emerald-900/20 border border-emerald-500/20">
            <FiCpu className="w-4 h-4 text-emerald-400 animate-pulse" />
            <p className="text-emerald-400 text-sm animate-pulse">
              AI is analyzing job market + matching your profile with {skills.length} skill{skills.length !== 1 ? 's' : ''}...
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Array(3).fill(0).map((_, i) => <SkeletonCard key={i} />)}
          </div>
        </>
      )}

      {error && (
        <div className="flex items-center gap-2 p-4 mb-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
          <FiAlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Global Missing Skills / Skill Gap Insight */}
      {!loading && globalMissing.length > 0 && (
        <div className="p-4 mb-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
          <div className="flex items-center gap-2 mb-2">
            <FiTarget className="w-4 h-4 text-yellow-400" />
            <p className="text-xs text-yellow-400 uppercase tracking-wider font-semibold">Skill Gap Insight</p>
          </div>
          <div className="flex flex-wrap gap-2 mb-1.5">
            {globalMissing.map((skill, i) => (
              <span key={i} className="px-2.5 py-1 rounded-md text-xs bg-yellow-500/15 text-yellow-300 border border-yellow-500/25">
                {skill}
              </span>
            ))}
          </div>
          <p className="text-xs text-yellow-300/70">Recommended to learn these to improve your match scores</p>
        </div>
      )}

      {!searched && !loading && (
        <div className="flex flex-col items-center justify-center py-16 text-gray-500">
          <FiTarget className="w-10 h-10 mb-3 opacity-40" />
          <p className="text-sm">Add your skills above to get personalized job matches</p>
        </div>
      )}

      {/* Empty State */}
      {searched && !loading && jobs.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400">
          <FiSearch className="w-10 h-10 mb-3 opacity-40" />
          <p className="font-medium">No matching jobs found</p>
          <p className="text-sm text-gray-500 mt-1">Try updating your skills or adding different ones</p>
        </div>
      )}

      {/* Sort Controls + Results */}
      {!loading && displayJobs.length > 0 && (
        <>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-gray-400">{displayJobs.length} jobs matched</p>
            <div className="flex items-center gap-2">
              <FiArrowDown className="w-3.5 h-3.5 text-gray-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="text-xs bg-gray-800 border border-gray-700 text-gray-300 rounded-lg px-3 py-1.5
                  focus:outline-none focus:border-emerald-500/50"
              >
                <option value="match">Highest Match First</option>
                <option value="latest">Latest Jobs First</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {displayJobs.map((job, i) => (
              <JobCard key={job.id || i} job={job} index={i} userSkills={skills} />
            ))}
          </div>
        </>
      )}
    </section>
  )
}
