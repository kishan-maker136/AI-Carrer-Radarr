'use client'

import React from 'react'
import { FiBriefcase, FiMapPin, FiClock, FiExternalLink, FiAward, FiCpu, FiAlertTriangle } from 'react-icons/fi'
import { Job } from '@/lib/types/career'
import { getMatchLabel } from '@/utils/matchScore'

interface JobCardProps {
  job: Job
  index: number
  userSkills?: string[]
}

function getLocationColor(location: string) {
  const loc = (location || '').toLowerCase()
  if (loc.includes('remote')) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
  if (loc.includes('hybrid')) return 'bg-amber-500/20 text-amber-400 border-amber-500/30'
  return 'bg-blue-500/20 text-blue-400 border-blue-500/30'
}

function generateAIReason(job: Job, userSkills?: string[]): string {
  const skills = Array.isArray(job.skills) ? job.skills : []
  const score = job.match_score ?? 0

  if (userSkills && userSkills.length > 0) {
    const matched = skills.filter((s) =>
      userSkills.some((us) => us.toLowerCase() === s.toLowerCase())
    )
    if (matched.length > 0) {
      return `Matches your ${matched.slice(0, 3).join(', ')} skills and similar job history patterns.`
    }
  }

  if (score >= 80) {
    return `Strong alignment with ${skills.slice(0, 2).join(' & ')} requirements and market demand trends.`
  }
  if (score >= 50) {
    return `Partial match based on ${skills.slice(0, 2).join(' & ')} — upskilling could strengthen fit.`
  }
  return `Emerging opportunity — consider building ${skills.slice(0, 2).join(' & ')} skills for this role.`
}

export default function JobCard({ job, index, userSkills }: JobCardProps) {
  const score = job.match_score ?? Math.floor(Math.random() * 40 + 60)
  const match = getMatchLabel(score)
  const aiReason = generateAIReason({ ...job, match_score: score }, userSkills)

  return (
    <div
      className="group relative bg-gray-900 border border-gray-800 rounded-2xl p-5
        hover:scale-[1.02] hover:border-purple-500/40 hover:bg-gray-900/90
        transition-all duration-300 shadow-lg hover:-translate-y-1
        hover:shadow-xl hover:shadow-blue-500/20 animate-fadeInUp"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Match Score Badge with Label */}
      <div className="absolute top-4 right-4">
        <div className="flex gap-2 items-center">
          <FiAward className={`w-4 h-4 ${match.color}`} />
          <span className="text-white font-semibold text-sm">
            {score}% match
          </span>
          <span className={`${match.color} font-medium text-xs`}>
            ({match.label})
          </span>
        </div>
      </div>

      {/* Title & Company */}
      <h3 className="text-lg font-semibold text-white pr-44 group-hover:text-purple-300 transition-colors">
        {job.title || 'Untitled Position'}
      </h3>
      <div className="flex items-center gap-2 mt-1.5 text-gray-400">
        <FiBriefcase className="w-3.5 h-3.5" />
        <span className="text-sm">{job.company || 'Company Not Listed'}</span>
      </div>

      {/* Location & Experience */}
      <div className="flex flex-wrap items-center gap-2 mt-3">
        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getLocationColor(job.location)}`}>
          <FiMapPin className="w-3 h-3" />
          {job.location || 'Not specified'}
        </span>
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-purple-500/20 text-purple-300 border border-purple-500/30">
          <FiClock className="w-3 h-3" />
          {job.experience || 'Not specified'}
        </span>
      </div>

      {/* Skills */}
      <div className="mt-3.5">
        <p className="text-xs text-gray-500 uppercase tracking-wider mb-1.5">Skills Required</p>
        <div className="flex flex-wrap gap-1.5">
          {Array.isArray(job.skills) && job.skills.length > 0 ? (
            job.skills.slice(0, 6).map((skill, i) => (
              <span key={i} className="px-2 py-0.5 rounded-md text-xs bg-gray-800/80 text-gray-300 border border-gray-700/60">
                {skill}
              </span>
            ))
          ) : (
            <span className="text-xs text-gray-500">No skills listed</span>
          )}
          {Array.isArray(job.skills) && job.skills.length > 6 && (
            <span className="px-2 py-0.5 rounded-md text-xs bg-gray-800/80 text-gray-400">
              +{job.skills.length - 6} more
            </span>
          )}
        </div>
      </div>

      {/* Missing Skills / Skill Gap Insight */}
      {Array.isArray(job.missing_skills) && job.missing_skills.length > 0 && (
        <div className="mt-3 p-2.5 rounded-lg bg-yellow-500/5 border border-yellow-500/15">
          <div className="flex items-center gap-1.5 mb-1.5">
            <FiAlertTriangle className="w-3.5 h-3.5 text-yellow-400" />
            <p className="text-xs text-yellow-400 font-semibold uppercase tracking-wider">Skill Gap Insight</p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {job.missing_skills.map((skill, i) => (
              <span key={i} className="px-2 py-0.5 rounded-md text-xs bg-yellow-500/10 text-yellow-300 border border-yellow-500/20">
                {skill}
              </span>
            ))}
          </div>
          <p className="text-xs text-yellow-300/70 mt-1.5">
            Recommended to improve match score
          </p>
        </div>
      )}

      {/* Gradient Match Score Bar */}
      <div className="mt-4">
        <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
          <div
            className="h-2 rounded-full bg-gradient-to-r from-green-400 to-blue-500 transition-all duration-700"
            style={{ width: `${score}%` }}
          />
        </div>
      </div>

      {/* AI Reason Line */}
      <div className="flex items-start gap-2 mt-3">
        <FiCpu className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
        <p className="text-sm text-gray-400 leading-relaxed">
          <span className="text-blue-400 font-medium">AI Reason:</span> {aiReason}
        </p>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-800/60">
        <span className="text-xs text-gray-500">
          {job.posted_date || 'Recently posted'}
        </span>
        <a
          href={job.apply_url || '#'}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium
            bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90
            text-white transition-all duration-200 hover:shadow-md hover:shadow-purple-500/25"
        >
          Apply Now
          <FiExternalLink className="w-3 h-3" />
        </a>
      </div>
    </div>
  )
}
