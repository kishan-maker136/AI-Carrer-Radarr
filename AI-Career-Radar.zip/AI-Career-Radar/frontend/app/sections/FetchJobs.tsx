'use client'

import React, { useState } from 'react'
import { FiDownloadCloud, FiLoader, FiAlertCircle, FiDatabase, FiCpu, FiSearch, FiArrowDown } from 'react-icons/fi'
import JobCard from './JobCard'
import SkeletonCard from './SkeletonCard'
import { Job } from '@/lib/types/career'

type SortOption = 'match' | 'latest'

function parseJobs(data: any): Job[] {
  if (!data) return []
  if (Array.isArray(data)) return data
  // Backend /fetch returns { results: [...] }
  if (Array.isArray(data.results)) return data.results
  if (Array.isArray(data.jobs)) return data.jobs
  if (Array.isArray(data.data)) return data.data
  if (data.data && Array.isArray(data.data.results)) return data.data.results
  if (data.data && Array.isArray(data.data.jobs)) return data.data.jobs
  for (const key of Object.keys(data)) {
    if (Array.isArray(data[key]) && data[key].length > 0 && typeof data[key][0] === 'object') {
      return data[key]
    }
  }
  return []
}

function sortJobs(jobs: Job[], sort: SortOption): Job[] {
  const sorted = [...jobs]
  if (sort === 'match') {
    sorted.sort((a, b) => (b.match_score ?? 0) - (a.match_score ?? 0))
  } else {
    sorted.sort((a, b) => {
      const dateA = a.posted_date ? new Date(a.posted_date).getTime() : 0
      const dateB = b.posted_date ? new Date(b.posted_date).getTime() : 0
      return dateB - dateA
    })
  }
  return sorted
}

export default function FetchJobs() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [fetched, setFetched] = useState(false)
  const [sortBy, setSortBy] = useState<SortOption>('match')

  const fetchJobs = async () => {
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/career', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'fetch' }),
      })
      const result = await res.json()
      if (result.success) {
        const parsed = parseJobs(result.data)
        setJobs(parsed)
        setFetched(true)
      } else {
        setError(result.error || 'Failed to fetch jobs')
      }
    } catch (err: any) {
      setError(err.message || 'Network error')
    } finally {
      setLoading(false)
    }
  }

  const displayJobs = sortJobs(jobs, sortBy)

  return (
    <section>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-500/20 border border-blue-500/30">
            <FiDatabase className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Fetch Jobs</h2>
            <p className="text-sm text-gray-400">Pull latest job listings from the database</p>
          </div>
        </div>
        <button
          onClick={fetchJobs}
          disabled={loading}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium
            bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90
            text-white transition-all duration-200
            disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-blue-500/25"
        >
          {loading ? (
            <FiLoader className="w-4 h-4 animate-spin" />
          ) : (
            <FiDownloadCloud className="w-4 h-4" />
          )}
          {loading ? 'Loading...' : 'Fetch Jobs'}
        </button>
      </div>

      {/* AI Thinking State */}
      {loading && (
        <>
          <div className="flex items-center gap-2 p-3 mb-4 rounded-xl bg-blue-900/20 border border-blue-500/20">
            <FiCpu className="w-4 h-4 text-blue-400 animate-pulse" />
            <p className="text-blue-400 text-sm animate-pulse">
              AI is analyzing job market and fetching latest listings...
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Array(4).fill(0).map((_, i) => <SkeletonCard key={i} />)}
          </div>
        </>
      )}

      {error && (
        <div className="flex items-center gap-2 p-4 mb-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
          <FiAlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {!fetched && !loading && !error && (
        <div className="flex flex-col items-center justify-center py-16 text-gray-500">
          <FiDownloadCloud className="w-10 h-10 mb-3 opacity-40" />
          <p className="text-sm">Click &quot;Fetch Jobs&quot; to load the latest listings</p>
        </div>
      )}

      {/* Empty State */}
      {fetched && !loading && jobs.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400">
          <FiSearch className="w-10 h-10 mb-3 opacity-40" />
          <p className="font-medium">No matching jobs found</p>
          <p className="text-sm text-gray-500 mt-1">Try again later or check your backend connection</p>
        </div>
      )}

      {/* Sort Controls + Results */}
      {!loading && displayJobs.length > 0 && (
        <>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-gray-400">{displayJobs.length} jobs found</p>
            <div className="flex items-center gap-2">
              <FiArrowDown className="w-3.5 h-3.5 text-gray-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="text-xs bg-gray-800 border border-gray-700 text-gray-300 rounded-lg px-3 py-1.5
                  focus:outline-none focus:border-blue-500/50"
              >
                <option value="match">Highest Match First</option>
                <option value="latest">Latest Jobs First</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {displayJobs.map((job, i) => (
              <JobCard key={job.id || i} job={job} index={i} />
            ))}
          </div>
        </>
      )}
    </section>
  )
}
