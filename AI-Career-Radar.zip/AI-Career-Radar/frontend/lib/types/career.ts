export interface Job {
  id?: string | number
  title: string
  company: string
  skills: string[]
  experience: string
  location: string
  posted_date: string
  match_score?: number
  missing_skills?: string[]
  apply_url?: string
}

export interface FetchJobsResponse {
  success: boolean
  data?: {
    jobs?: Job[]
    [key: string]: any
  }
  error?: string
}

export interface SearchJobsResponse {
  success: boolean
  data?: {
    jobs?: Job[]
    results?: Job[]
    [key: string]: any
  }
  error?: string
}

export interface RecommendResponse {
  success: boolean
  data?: {
    jobs?: Job[]
    recommendations?: Job[]
    matched_jobs?: Job[]
    missing_skills?: string[]
    [key: string]: any
  }
  error?: string
}
