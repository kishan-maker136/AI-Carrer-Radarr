export function getMatchLabel(score: number) {
  if (score >= 80) return { label: "Strong Fit", color: "text-green-400" };
  if (score >= 50) return { label: "Moderate Fit", color: "text-yellow-400" };
  return { label: "Weak Fit", color: "text-red-400" };
}
